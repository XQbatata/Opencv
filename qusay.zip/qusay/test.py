import cv2 as cv
'''
pic = cv.imread("p10376284_b_v13_ba.jpg",1)
re = cv.resize(pic, (800,600))
cv.imshow("hello",pic)
cv.imshow("hi",re)
cv.waitKey()
'''

camera = cv.VideoCapture(0)

while True:
    right, pic = camera.read()
    resize = cv.resize(pic,(800,600))
    gray = cv.cvtColor(resize, cv.COLOR_BGR2GRAY) 
    cv.putText(gray, 'Qusay laila', (200,500), cv.FONT_HERSHEY_TRIPLEX, 2, (0, 0, 255,), 2)


    cv.imshow("QUSAY", gray)

    key = cv.waitKey(1)# to exit the camera press Esc
    if key%255 == 27:
        break









